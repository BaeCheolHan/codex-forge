# 용어집

> 전체 workspace 공통 용어 정의

| 용어 | 정의 | 비고 |
|------|------|------|
| Workspace | `.codex-root`가 있는 디렉토리 | MSA 루트 |
| Repo | workspace 1depth 하위 폴더 | 개별 서비스 |
| Active scope | 현재 작업 대상 repo 집합 | - |
