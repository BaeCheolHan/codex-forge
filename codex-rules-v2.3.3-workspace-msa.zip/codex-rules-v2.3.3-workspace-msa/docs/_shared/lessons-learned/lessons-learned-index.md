# 교훈 인덱스

> 태그별 분류 인덱스

## 태그 목록
- `process`, `scope`, `tools`, `ux`, `review`, `docs`
- `arch`, `msa`, `design`, `api`, `dto`, `test`
- `db`, `sql`, `mysql`, `migration`
- `perf`, `concurrency`, `memory`, `io`
- `auth`, `jwt`, `secrets`, `vuln`
