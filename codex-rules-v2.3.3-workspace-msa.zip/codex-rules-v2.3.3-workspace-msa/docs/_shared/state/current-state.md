# Current State

> 현재 작업 상태 (비커밋). ≤6줄 유지.

## Active Scope
- codex-forge (PROD-00001) → `docs/_shared/state/current-state.d/codex-forge.md`

## 최근 작업
- [2026-01-30] PROD-00001 install.sh 단독 실행 + rules 덮어쓰기 프롬프트 + config 병합
