# State Log

> 상태 변경 로그 (비커밋).

## 형식
```
[YYYY-MM-DD HH:MM] 변경 요약
```
