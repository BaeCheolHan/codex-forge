# codex-forge State

## 요약 (≤12줄)
- 상태: install.sh 단독 실행 + rules 덮어쓰기 프롬프트 + config 병합 반영
- 마지막 변경: 2026-01-30
- 주요 이슈: git fallback 설치 + rules 스킵 옵션 (PROD-00001)

## 최근 변경
- PROD-00001: install.sh 단독 다운로드 실행 및 rules 덮어쓰기 확인 추가
- config.toml MCP 블록 병합 처리

## 다음 액션
- 오프라인 설치 대안 필요 시 문서화
- 릴리스 체크리스트 실행(선택)
