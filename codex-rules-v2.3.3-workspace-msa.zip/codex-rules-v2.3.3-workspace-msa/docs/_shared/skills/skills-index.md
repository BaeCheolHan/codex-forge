# Skills Index

> 등록된 스킬 목록. 형식: `S-NNN [tags] <skill-name> — when / inputs / outputs`

## 등록 스킬
(없음 - 첫 스킬 등록 시 여기에 추가)
