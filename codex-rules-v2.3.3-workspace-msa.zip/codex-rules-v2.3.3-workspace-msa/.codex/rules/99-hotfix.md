# 99 Hotfix

- "핫픽스"는 속도를 올리되 P0~P2(안전/무결성/예산)를 절대 완화하지 않는다.
- Change/Run 승인 게이트는 유지한다.
- Preflight/Postflight(문서 루프)도 유지하되, 예산 내에서만 최소로 수행한다.

- **예외 없음**: Hotfix라도 `02-knowledge.md`의 Debt 기록(필요 시 1~2줄)과
  `01-checklists.md`의 **최소 업데이트(경로 목록 + current-state ≤6줄)**는 반드시 수행한다.
